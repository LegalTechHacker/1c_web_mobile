module.exports = {
  prefix: 'tw-',
  theme: {
    extend: {}
  },
  variants: {},
  plugins: []
}
