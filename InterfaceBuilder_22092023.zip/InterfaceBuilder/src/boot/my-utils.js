import Vue from 'vue'
import utils from 'src/plugins/utils'

Vue.use(utils)
