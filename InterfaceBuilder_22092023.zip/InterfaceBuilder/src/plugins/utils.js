import AppMixin from '../mixins/app.mixin'

export default {
  install (Vue) {
    Vue.mixin(AppMixin)
  }
}
